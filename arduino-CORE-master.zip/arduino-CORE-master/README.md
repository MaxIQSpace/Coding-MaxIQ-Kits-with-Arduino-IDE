# xChip xCore
Core for XinaBox xChip Platforms

## Requirements
  - [Arduino IDE](https://www.arduino.cc/en/main/software)
  - xChip [Core](https://xinabox.cc/collections/core)
  
## Installation Guide
To install the libraries please followed the guide provided on the [Arduino Website](https://www.arduino.cc/en/Guide/Libraries) under "**Importing a .zip Library**".
